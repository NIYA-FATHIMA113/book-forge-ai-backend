import os
import json

from dotenv import load_dotenv
from groq import Groq
from openai import OpenAI
from google import genai
from google.genai import types
from ai_assistant.schemas import BusinessInfo, BookingRequest

load_dotenv()


# ============================================================
# API KEYS
# ============================================================

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")


# ============================================================
# MODELS
# ============================================================

GROQ_MODEL = os.getenv(
    "GROQ_MODEL",
    "openai/gpt-oss-20b",
)
OPENROUTER_MODEL = os.getenv(
    "OPENROUTER_MODEL",
    "openai/gpt-oss-20b",
)
GEMINI_MODEL = os.getenv(
    "GEMINI_MODEL",
    "gemini-2.5-flash",
)


# ============================================================
# CLIENTS
# ============================================================

groq_client = (
    Groq(api_key=GROQ_API_KEY)
    if GROQ_API_KEY
    else None
)

openrouter_client = (
    OpenAI(
        api_key=OPENROUTER_API_KEY,
        base_url="https://openrouter.ai/api/v1",
    )
    if OPENROUTER_API_KEY
    else None
)

gemini_client = (
    genai.Client(api_key=GEMINI_API_KEY)
    if GEMINI_API_KEY
    else None
)


# ============================================================
# SYSTEM PROMPT
# ============================================================

SYSTEM_PROMPT = """
You are BookForge AI, an AI business assistant.

You help small business owners manage and grow their businesses.

You can help with:
- marketing
- social media
- customer service
- bookings
- staff scheduling
- business planning
- business ideas
- promotions
- daily operations

Be helpful, concise, professional and friendly.

If the user provides information about their business,
use that information naturally in future responses.
"""


# ============================================================
# MESSAGE NORMALIZATION
# ============================================================

def normalize_messages(conversation_history):
    """
    Convert incoming conversation history into a safe,
    OpenAI-compatible message format.
    """

    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        }
    ]

    for message in conversation_history or []:

        if not isinstance(message, dict):
            continue

        role = message.get("role")
        if role == "model":
            role = "assistant"

        content = message.get("content")
        if content is None:
            parts = message.get("parts")
            if isinstance(parts, list):
                content = " ".join(
                    part.get("text", "")
                    for part in parts
                    if isinstance(part, dict)
                )

        if role not in ("user", "assistant"):
            continue

        if not isinstance(content, str):
            continue

        content = content.strip()

        if not content:
            continue

        messages.append(
            {
                "role": role,
                "content": content,
            }
        )

    return messages


# ============================================================
# GROQ
# ============================================================

def groq_generate(messages):
    """
    Generate a response using Groq.
    """

    if not groq_client:
        raise RuntimeError("GROQ_API_KEY is not configured.")

    response = groq_client.chat.completions.create(
        model=GROQ_MODEL,
        messages=messages,
        temperature=0.2,
        max_tokens=1000,
    )

    content = response.choices[0].message.content

    if not content:
        raise RuntimeError("Groq returned an empty response.")

    return content.strip()


# ============================================================
# OPENROUTER
# ============================================================

def openrouter_generate(messages):
    """
    Generate a response using OpenRouter.
    """

    if not openrouter_client:
        raise RuntimeError(
            "OPENROUTER_API_KEY is not configured."
        )

    response = openrouter_client.chat.completions.create(
        model=OPENROUTER_MODEL,
        messages=messages,
        temperature=0.2,
        max_tokens=1000,
    )

    content = response.choices[0].message.content

    if not content:
        raise RuntimeError(
            "OpenRouter returned an empty response."
        )

    return content.strip()


# ============================================================
# GEMINI MESSAGE CONVERSION
# ============================================================

def convert_to_gemini_contents(messages):
    """
    Convert OpenAI-style messages into Gemini Content objects.
    """

    contents = []

    for message in messages:

        role = message.get("role")
        text = message.get("content", "").strip()

        if not text:
            continue

        if role == "user":
            gemini_role = "user"

        elif role == "assistant":
            gemini_role = "model"

        else:
            # System prompt is handled separately.
            continue

        contents.append(
            types.Content(
                role=gemini_role,
                parts=[
                    types.Part.from_text(text=text)
                ],
            )
        )

    return contents


# ============================================================
# GEMINI
# ============================================================

def gemini_generate(messages):
    """
    Generate a response using Gemini.
    """

    if not gemini_client:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured."
        )

    contents = convert_to_gemini_contents(messages)

    if not contents:
        raise RuntimeError(
            "No valid messages were supplied to Gemini."
        )

    response = gemini_client.models.generate_content(
        model=GEMINI_MODEL,
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            temperature=0.2,
            max_output_tokens=1000,
        ),
    )

    text = response.text

    if not text:
        raise RuntimeError(
            "Gemini returned an empty response."
        )

    return text.strip()


# ============================================================
# MAIN AI RESPONSE FUNCTION
# ============================================================

def generate_ai_response(conversation_history):
    """
    Try AI providers in this order: Gemini, Groq, OpenRouter.

    If one provider fails, automatically try the next one.
    """

    messages = normalize_messages(
        conversation_history
    )

    if len(messages) <= 1:
        raise RuntimeError(
            "No valid user message was provided."
        )

    if not any((gemini_client, groq_client, openrouter_client)):
        raise RuntimeError(
            "No AI provider is configured. Set GEMINI_API_KEY, "
            "GROQ_API_KEY, or OPENROUTER_API_KEY."
        )

    errors = []

    # --------------------------------------------------------
    # GEMINI
    # --------------------------------------------------------

    try:
        print("Trying Gemini...")

        result = gemini_generate(messages)

        print("Gemini succeeded.")

        return result

    except Exception as exc:

        print(f"Gemini failed: {exc.__class__.__name__}")

        errors.append(
            f"Gemini: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # GROQ
    # --------------------------------------------------------

    try:
        print("Trying Groq...")

        result = groq_generate(messages)

        print("Groq succeeded.")

        return result

    except Exception as exc:

        print(f"Groq failed: {exc.__class__.__name__}")

        errors.append(
            f"Groq: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # OPENROUTER
    # --------------------------------------------------------

    try:
        print("Trying OpenRouter...")

        result = openrouter_generate(messages)

        print("OpenRouter succeeded.")

        return result

    except Exception as exc:

        print(f"OpenRouter failed: {exc.__class__.__name__}")

        errors.append(
            f"OpenRouter: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # EVERYTHING FAILED
    # --------------------------------------------------------

    print(
        "All AI providers failed:",
        errors
    )

    raise RuntimeError(
        "AI service is temporarily unavailable. "
        "Please try again shortly."
    )


# ============================================================
# BUSINESS INFORMATION EXTRACTION
# ============================================================

BUSINESS_EXTRACTION_PROMPT = """
Extract business information from the user's message.

Return ONLY valid JSON.

Possible fields:

{
    "business_name": "",
    "business_type": "",
    "services": [
        {
            "name": "",
            "price": null,
            "duration_minutes": null
        }
    ],
    "location": "",
    "description": ""
}

Rules:

- Only include information clearly provided by the user.
- Do not invent information.
- Use empty strings when information is unavailable.
"""


def parse_json_response(content):
    """Parse model JSON while tolerating a markdown code fence."""

    content = content.strip()

    if content.startswith("```json"):
        content = content[7:]
    elif content.startswith("```"):
        content = content[3:]

    if content.endswith("```"):
        content = content[:-3]

    return json.loads(content.strip())


def parse_business_info_response(content):
    """Normalize provider JSON into the existing BusinessInfo schema."""

    data = parse_json_response(content)
    services = data.get("services", [])

    if isinstance(services, list):
        data["services"] = [
            {"name": service} if isinstance(service, str) else service
            for service in services
        ]

    return BusinessInfo.model_validate(data)


def extract_business_info_with_groq(text):
    """
    Extract business information using Groq.
    """

    if not groq_client:
        raise RuntimeError(
            "GROQ_API_KEY is not configured."
        )

    response = groq_client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[
            {
                "role": "system",
                "content": BUSINESS_EXTRACTION_PROMPT,
            },
            {
                "role": "user",
                "content": text,
            },
        ],
        temperature=0,
        max_tokens=300,
    )

    content = response.choices[0].message.content

    if not content:
        raise RuntimeError(
            "Groq returned empty business information."
        )

    return parse_business_info_response(content)


def extract_business_info_with_openrouter(text):
    """
    Extract business information using OpenRouter.
    """

    if not openrouter_client:
        raise RuntimeError(
            "OPENROUTER_API_KEY is not configured."
        )

    response = openrouter_client.chat.completions.create(
        model=OPENROUTER_MODEL,
        messages=[
            {
                "role": "system",
                "content": BUSINESS_EXTRACTION_PROMPT,
            },
            {
                "role": "user",
                "content": text,
            },
        ],
        temperature=0,
        max_tokens=300,
    )

    content = response.choices[0].message.content

    if not content:
        raise RuntimeError(
            "OpenRouter returned empty business information."
        )

    return parse_business_info_response(content)


def extract_business_info_with_gemini(text):
    """
    Extract business information using Gemini.
    """

    if not gemini_client:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured."
        )

    response = gemini_client.models.generate_content(
        model=GEMINI_MODEL,
        contents=text,
        config=types.GenerateContentConfig(
            system_instruction=BUSINESS_EXTRACTION_PROMPT,
            temperature=0,
            max_output_tokens=300,
        ),
    )

    content = response.text

    if not content:
        raise RuntimeError(
            "Gemini returned empty business information."
        )

    return parse_business_info_response(content)


# ============================================================
# BUSINESS INFORMATION FALLBACK
# ============================================================

def extract_business_info(text):
    """
    Try business extraction through:

        Groq → OpenRouter → Gemini
    """

    if not text or not text.strip():
        return BusinessInfo()

    errors = []

    # --------------------------------------------------------
    # GROQ
    # --------------------------------------------------------

    try:
        print("Trying Groq business extraction...")

        result = extract_business_info_with_groq(text)

        print("Groq business extraction succeeded.")

        return result

    except Exception as exc:

        print(
            "Groq business extraction failed: "
            f"{exc.__class__.__name__}"
        )

        errors.append(
            f"Groq: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # OPENROUTER
    # --------------------------------------------------------

    try:
        print(
            "Trying OpenRouter business extraction..."
        )

        result = extract_business_info_with_openrouter(
            text
        )

        print(
            "OpenRouter business extraction succeeded."
        )

        return result

    except Exception as exc:

        print(
            "OpenRouter business extraction failed: "
            f"{exc.__class__.__name__}"
        )

        errors.append(
            f"OpenRouter: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # GEMINI
    # --------------------------------------------------------

    try:
        print(
            "Trying Gemini business extraction..."
        )

        result = extract_business_info_with_gemini(
            text
        )

        print(
            "Gemini business extraction succeeded."
        )

        return result

    except Exception as exc:

        print(
            "Gemini business extraction failed: "
            f"{exc.__class__.__name__}"
        )

        errors.append(
            f"Gemini: {exc.__class__.__name__}"
        )

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    print(
        "All business extraction providers failed:",
        errors
    )

    return BusinessInfo()
def extract_booking_request(text):
    """
    Extract booking information from a user's message.

    This function is kept compatible with booking_ai.py.
    """

    if not text or not text.strip():
        return BookingRequest()

    prompt = f"""
Extract booking information from the following user message.

Return ONLY valid JSON.

Possible fields:

{{
    "customer_name": "",
    "business_name": "",
    "booking_date": "",
    "booking_time": "",
    "duration_minutes": null,
    "service_name": "",
    "customer_name": "",
    "customer_phone": ""
}}

Rules:
- Only extract information explicitly provided.
- Do not invent information.
- Use empty strings for missing information.

User message:
{text}
"""

    messages = [
        {
            "role": "system",
            "content": "You extract structured booking information from messages."
        },
        {
            "role": "user",
            "content": prompt
        }
    ]

    errors = []

    # --------------------------------------------------------
    # GROQ
    # --------------------------------------------------------

    try:
        print("Trying Groq booking extraction...")

        if groq_client:
            response = groq_client.chat.completions.create(
                model=GROQ_MODEL,
                messages=messages,
                temperature=0,
                max_tokens=300,
            )

            content = response.choices[0].message.content

            if content:
                return BookingRequest.model_validate(
                    parse_json_response(content)
                )

    except Exception as exc:
        print(
            "Groq booking extraction failed: "
            f"{exc.__class__.__name__}"
        )
        errors.append(f"Groq: {exc.__class__.__name__}")

    # --------------------------------------------------------
    # OPENROUTER
    # --------------------------------------------------------

    try:
        print(
            "Trying OpenRouter booking extraction..."
        )

        if openrouter_client:
            response = openrouter_client.chat.completions.create(
                model=OPENROUTER_MODEL,
                messages=messages,
                temperature=0,
                max_tokens=300,
            )

            content = response.choices[0].message.content

            if content:
                return BookingRequest.model_validate(
                    parse_json_response(content)
                )

    except Exception as exc:
        print(
            "OpenRouter booking extraction failed: "
            f"{exc.__class__.__name__}"
        )
        errors.append(f"OpenRouter: {exc.__class__.__name__}")

    # --------------------------------------------------------
    # GEMINI
    # --------------------------------------------------------

    try:
        print(
            "Trying Gemini booking extraction..."
        )

        if gemini_client:
            response = gemini_client.models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=(
                        "Extract booking information and "
                        "return only valid JSON."
                    ),
                    temperature=0,
                    max_output_tokens=300,
                ),
            )

            content = response.text

            if content:
                return BookingRequest.model_validate(
                    parse_json_response(content)
                )

    except Exception as exc:
        print(
            "Gemini booking extraction failed: "
            f"{exc.__class__.__name__}"
        )
        errors.append(f"Gemini: {exc.__class__.__name__}")

    # --------------------------------------------------------
    # NO PROVIDER AVAILABLE
    # --------------------------------------------------------

    print(
        "All booking extraction providers failed:",
        errors
    )

    return BookingRequest()